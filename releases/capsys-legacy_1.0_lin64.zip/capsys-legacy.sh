LD_LIBRARY_PATH="$LD_LIBRARY_PATH:./" ./capsys-legacy
